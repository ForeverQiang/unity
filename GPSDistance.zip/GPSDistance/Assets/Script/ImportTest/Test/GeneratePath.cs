﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class GeneratePath : MonoBehaviour {
    #region
    //private string lonlan = "{23.218828055555555,113.30181833333333},{23.218858333333333,113.30185305555555},{23.219005833333334,113.30208305555556},{23.219005833333334,113.30208305555556},{23.21926611111111,113.30253444444445},{23.21926611111111,113.30253444444445},{23.21947861111111,113.30293805555556},{23.21947861111111,113.30293805555556},{23.21956972222222,113.30305944444444},{23.219734444444445,113.30317222222222},{23.219734444444445,113.30317222222222},{23.219864444444443,113.30325027777778},{23.219864444444443,113.30325027777778},{23.220020555555557,113.3033413888889},{23.220020555555557,113.3033413888889},{23.220337222222224,113.30350194444445},{23.220337222222224,113.30350194444445},{23.22065388888889,113.30362333333333},{23.220655277777777,113.3036238888889},{23.220594722222224,113.303945},{23.220590277777777,113.30394527777777},{23.220872222222223,113.304045},{23.220872222222223,113.304045},{23.22091111111111,113.30393222222222},{23.22091138888889,113.30392777777777},{23.2212325,113.3040275}";
    private string lanlon0 = "23.218828055555555,113.30181833333333";
    private string lanlon1 = "23.218858333333333,113.30185305555555";
    private string lanlon2 = "23.219005833333334,113.30208305555556";
    private string lanlon3 = "23.219005833333334,113.30208305555556";
    private string lanlon4 = "23.21926611111111,113.30253444444445";
    private string lanlon5 = "23.21926611111111,113.30253444444445";
    private string lanlon6 = "23.21947861111111,113.30293805555556";
    private string lanlon7 = "23.21947861111111,113.30293805555556";
    private string lanlon8 = "23.21956972222222,113.30305944444444";
    private string lanlon9 = "23.219734444444445,113.30317222222222";
    private string lanlon10 = "23.219734444444445,113.30317222222222";
    private string lanlon11 = "23.219864444444443,113.30325027777778";
    private string lanlon12 = "23.219864444444443,113.30325027777778";
    private string lanlon13 = "23.220020555555557,113.3033413888889";
    private string lanlon14 = "23.220020555555557,113.3033413888889";
    private string lanlon15 = "23.220337222222224,113.30350194444445";
    private string lanlon16 = "23.220337222222224,113.30350194444445";
    private string lanlon17 = "23.22065388888889,113.30362333333333";
    private string lanlon18 = "23.220655277777777,113.3036238888889";
    private string lanlon19 = "23.220594722222224,113.303945";
    private string lanlon20 = "23.220590277777777,113.30394527777777";
    private string lanlon21 = "23.220872222222223,113.304045";
    private string lanlon22 = "23.220872222222223,113.304045";
    private string lanlon23 = "23.22091111111111,113.30393222222222";
    private string lanlon24 = "23.22091138888889,113.30392777777777";
    private string lanlon25 = "23.2212325,113.3040275";
    #endregion
    public string startLanlon = "23.219094509549,113.301577148438";
    public string endLanlon = "23.221594,113.303885";
    private List<string> lanlon = new List<string>() {
        "23.218828055555555,113.30181833333333",
        "23.218858333333333,113.30185305555555",
        "23.219005833333334,113.30208305555556",
        "23.219005833333334,113.30208305555556",
        "23.21926611111111,113.30253444444445",
        "23.21926611111111,113.30253444444445",
        "23.21947861111111,113.30293805555556",
        "23.21947861111111,113.30293805555556",
        "23.21956972222222,113.30305944444444",
        "23.219734444444445,113.30317222222222",
         "23.219734444444445,113.30317222222222",
         "23.219864444444443,113.30325027777778",
         "23.219864444444443,113.30325027777778",
         "23.220020555555557,113.3033413888889",
         "23.220020555555557,113.3033413888889",
         "23.220337222222224,113.30350194444445",
         "23.220337222222224,113.30350194444445",
         "23.22065388888889,113.30362333333333",
         "23.220655277777777,113.3036238888889",
         "23.220594722222224,113.303945",
         "23.220590277777777,113.30394527777777",
         "23.220872222222223,113.304045",
         "23.220872222222223,113.304045",
         "23.22091111111111,113.30393222222222",
         "23.22091138888889,113.30392777777777",
         "23.2212325,113.3040275" };
    private pois poi;
    public SetAngle setAngle;
    public List<Transform> pos1 = new List<Transform>();
    private Create create = new Create();
    public GameObject test;

    private void Start()
    {
        GenerateGPS();
    }

    void GenerateGPS() {
        int startGoToSign = startLanlon.IndexOf(',');
        string originZ = startLanlon.Substring(0, startGoToSign);
        string originX = startLanlon.Substring(startGoToSign + 1);
        ARMapGloe.mylonLat = new LongLat(double.Parse(originX), double.Parse(originZ));

        for (int i = 0; i < lanlon.Count; i++) {
            poi = new pois();
            GameObject objs = GameObject.Instantiate(test) as GameObject;//Resources.Load("GPSPos")

            int GoToSign = lanlon[i].IndexOf(',');
            string Z = lanlon[i].Substring(0, GoToSign);
            string X = lanlon[i].Substring(GoToSign + 1);
            //ARMapGloe.mylonLat = new LongLat(double.Parse(X), double.Parse(Z));
            poi.longLat = new LongLat(double.Parse(X), double.Parse(Z));

            Vector3 aPos = new Vector3((float)ARMapGloe.mylonLat.Ec, 0, (float)ARMapGloe.mylonLat.Ed);
            Vector3 bPos = new Vector3((float)poi.longLat.Ec, 0, (float)poi.longLat.Ed);

            objs.transform.position = new Vector3(0, 0, Vector3.Distance(aPos, bPos)); ///3.5f  ARMapGloe.mylonLat.m_LoSec - pois.longLat.m_LoSec
            objs.transform.RotateAround(Vector3.zero, Vector3.up, GetAngle(ARMapGloe.mylonLat, poi.longLat) / 1f);

            //objs.transform.SetParent(Storage.GPSPath.transform);
            pos1.Add(objs.transform);
        }
        int endGoToSign = endLanlon.IndexOf(',');
        string endZ = endLanlon.Substring(0, endGoToSign);
        string endX = endLanlon.Substring(endGoToSign + 1);
        pois poii = new pois();
        poii.longLat = new LongLat(double.Parse(endX), double.Parse(endZ));
        GameObject obj = GameObject.Instantiate(test) as GameObject;//new GameObject("GPSPos");//Resources.Load("GPSPos")

        Vector3 targetPos0 = new Vector3((float)ARMapGloe.mylonLat.Ec, 0, (float)ARMapGloe.mylonLat.Ed);
        Vector3 targetPos1 = new Vector3((float)poii.longLat.Ec, 0, (float)poii.longLat.Ed);

        obj.transform.position = new Vector3(0, 0, Vector3.Distance(targetPos0, targetPos1));///3.5f
        obj.transform.RotateAround(Vector3.zero, Vector3.up, GetAngle(ARMapGloe.mylonLat, poii.longLat) / 1f);
        //obj.transform.SetParent(Storage.GPSPath.transform);
        pos1.Add(obj.transform);
        GeneratePathTest(pos1);
    }

    void GeneratePathTest(List<Transform> pos) {
        create.CountDistance(pos);
    }

    public float GetAngle(LongLat A, LongLat B)
    {
        double dx = (B.m_RadLo - A.m_RadLo) * A.Ed;
        double dy = (B.m_RadLa - A.m_RadLa) * A.Ec;
        double angle = 0.0f;
        angle = Math.Atan(Math.Abs(dx / dy)) * 180 / Math.PI;
        double dLo = B.m_Longitude - A.m_Longitude;
        double dLa = B.m_Latitude - A.m_Latitude;
        if (dLo > 0 && dLa <= 0)
        {
            angle = (90 - angle) + 90;
            Debug.Log("经度大于0，纬度小于0");
        }
        else if (dLo <= 0 && dLa < 0)
        {
            angle = angle + 180;
            Debug.Log("经度小于0，纬度小于0");
        }
        else if (dLo < 0 && dLa >= 0)
        {
            angle = (90 - angle) + 270;
            Debug.Log("经度小于0，纬度大于0");
        }
        Debug.Log("原始角度！");
        return (float)angle;
    }



}
public class pois {
    /// <summary>    /// 商店ID    /// </summary>
    public string shopId;
    /// <summary>    /// 商店名称    /// </summary>
    public string name;
    /// <summary>    /// 商店地址    /// </summary>
    public string address;
    /// <summary>    /// 经纬度    /// </summary>
    public string location;
    /// <summary>    /// 位置    /// </summary>
    public LongLat longLat;
    /// <summary>    /// 自身与商店的距离    /// </summary>
    public string distance;
    /// <summary>    /// 商店图片    /// </summary>
    public string shopImage;
    /// <summary>    /// 电话    /// </summary>
    public string phone;
    /// <summary>    /// 优惠信息    /// </summary>
    public string disInfo;
    /// <summary>    /// 是否有更新新品    /// </summary>
    public string isNew;
    /// <summary>    /// 优惠    /// </summary>
    public string discount;
    /// <summary>    /// 拼团    /// </summary>
    public string groups;
    /// <summary>    /// 打折    /// </summary>
    public string discountOff;
    /// <summary>    /// 满减    /// </summary>
    public string fullCut;
    /// <summary>    /// 新品    /// </summary>
    public string newProduct;
    ///  <summary>    /// 用户满意度（满星/半星/空星）    /// </summary>
    public string customerSatisfaction;
}