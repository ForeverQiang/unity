﻿using UnityEngine;
using System.Collections;
using System;

public class LongLat {
    //常量  地球是一个椭圆 长半轴和短半轴
    public static double Rc = 6378137;
    public static double Rj = 6356725;

    public double m_LoDeg, m_LoMin, m_LoSec;//我的经度，经度的最小值，经度的
    public double m_LaDeg, m_LaMin, m_LaSec;//我的纬度，纬度的最小值，纬度的
    public double m_Longitude, m_Latitude;
    public double m_RadLo, m_RadLa;
    public double Ec;
    public double Ed;
    /// <summary>/// 经纬度类 经度在前 纬度在后
    /// 在中国第一个值大第二个	/// </summary>
    /// <param name="longitude">Longitude.</param>
    /// <param name="latitude">Latitude.</param>
    public LongLat(double longitude, double latitude)
    {
        m_LoDeg = (int)longitude;
        m_LoMin = (int)((longitude - m_LoDeg) * 60);
        m_LoSec = (longitude - m_LoDeg - m_LoMin / 60) * 3600;  //GPS定位纬度

        m_LaDeg = (int)latitude;
        m_LaMin = (int)((latitude - m_LaDeg) * 60);
        m_LaSec = (latitude - m_LaDeg - m_LaMin / 60) * 3600;  //GPS定位经度

        m_Longitude = longitude;
        m_Latitude = latitude;
        m_RadLo = longitude * Math.PI / 180; //计算纬度
        m_RadLa = latitude * Math.PI / 180;  //计算经度
        Ec = Rj + (Rc - Rj) * (90 - m_Latitude) / 90;
        Ed = Ec * (Math.Cos((float)m_RadLa));
    }

}
