﻿using UnityEngine;
using System.Collections;
using System;

public class SetAngle : MonoBehaviour {

    public float GetAngle(LongLat A, LongLat B)
    {
        double dx = (B.m_RadLo - A.m_RadLo) * A.Ed;
        double dy = (B.m_RadLa - A.m_RadLa) * A.Ec;
        double angle = 0.0f;
        angle = Math.Atan(Math.Abs(dx / dy)) * 180 / Math.PI;
        double dLo = B.m_Longitude - A.m_Longitude;
        double dLa = B.m_Latitude - A.m_Latitude;
        if (dLo > 0 && dLa <= 0)
        {
            angle = (90 - angle) + 90;
        }
        else if (dLo <= 0 && dLa < 0)
        {
            angle = angle + 180;
        }
        else if (dLo < 0 && dLa >= 0)
        {
            angle = (90 - angle) + 270;
        }
        return (float)angle;
    }
}
