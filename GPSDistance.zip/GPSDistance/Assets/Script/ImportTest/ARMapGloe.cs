﻿using UnityEngine;
using System.Collections;

public class ARMapGloe : MonoBehaviour {

    public static LongLat mylonLat = null;

    public static string mylonLatString = "";//113.3500,23.230
                                             //public static string myLongLatType;
                                             //当前搜索的内容
                                             //public static string searchInfo=null;
    public static string searchKeyWords = "";//搜索关键字

    public static float firstTrueHeading;
}
