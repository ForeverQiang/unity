﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Storage : MonoBehaviour {

    public static List<GameObject> CreateInformation;//记录所有箭头//= new List<GameObject>();
    public static GameObject obj;           //设置箭头移动方法
    public static GameObject preform;       //箭头根物体
    public static GameObject movePath;      //箭头父物体
    public static GameObject testPath;      //测试箭头下移
    public static GameObject GPSPath;       //记录导航路点
    public static string shopName = "";     //记录导航商店按钮
    public static string buttonName = "";   //记录导航按钮
    public static GameObject panel_Compass; //记录指南针
    public static GameObject keepOut;       //是否取消导航

    public static float rotationXValue;     //记录相机真实X轴旋转值

    public static Vector3 v3;               //存放射线获取到点的位置

    public static GameObject distanceTime;  //记录商店距离
    public static string Instruction;       //记录路段怎么走
    public static string SectionDistance;   //记录当前路段距离
    public static int TotalDistance;        //记录总路段距离
    public static string Duration;          //记录所需要时间
    public static string ArriveTime;        //记录什么时候可以到达
    public static bool isGPS = false;       //标记是否在导航(默认没有导航)
    public static string destination = "";  //导航终点经纬度

    //public static List<GameObject> keepOut = new List<GameObject>();                                              //记录遮挡按钮
    public static Dictionary<string, int> shopTitle = new Dictionary<string, int>();                              //
    public static Dictionary<GameObject, GameObject> shopTitle1 = new Dictionary<GameObject, GameObject>();       //
    public static List<GameObject> objs = new List<GameObject>();                                                 //3D世界物体，用于商店UI的移动
    public static List<GameObject> objUI = new List<GameObject>();                                                //商店UI标记
    public static Dictionary<string, string> shopGPS = new Dictionary<string, string>();                          //记录商店名称与经纬度
    public static Dictionary<string, int> shopDistance = new Dictionary<string, int>();                           //所有商店的距离
    public static List<string> iD = new List<string>();                                                           //记录商店ID

    public static void Start()
    {
        CreateInformation = new List<GameObject>();
        testPath = new GameObject("TestPath");
        movePath = new GameObject("MovePath");
        preform = new GameObject("PreformW");
        testPath.transform.SetParent(preform.transform);
        movePath.transform.SetParent(testPath.transform);
    }
}
