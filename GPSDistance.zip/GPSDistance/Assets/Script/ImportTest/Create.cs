﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Create : MonoBehaviour {
    public GameObject startPos;

    public void CountDistance(List<Transform> pos)//Transform[] pos)
    {
        if (Storage.CreateInformation == null)
        {
            Storage.Start();
        }
        startPos = new GameObject("ABC");
        startPos.transform.position = Vector3.zero;
        //Storage.CreateInformation.Clear();
        if (pos == null) { Debug.Log("空"); }
        else
        {
            for (int i = 0; i < pos.Count; i++)
            {

                var d = Vector3.Distance(startPos.transform.position, pos[i].position);//A点与B点的距离  startPos.transform.position

                float xx = ((pos[i].position.x - startPos.transform.position.x) / d) / 2;//(d - 1))/5;//X每次需要增加的值  ,startPos.transform.position.x   0
                float zx = ((pos[i].position.z - startPos.transform.position.z) / d) / 2;//(d - 1))/5;//Z每次需要增加的值  pos.position.z,startPos.transform.position.z   0
                for (int b = 0; b < (d * 2) - 5; b++)
                {
                    GameObject gob = GameObject.Instantiate(Resources.Load("WhiteArrow")) as GameObject;//GPSPoolsManager.getInstance().nearPoints[b];
                    gob.SetActive(true);

                    gob.transform.position = new Vector3(gob.transform.position.x + Storage.v3.x, 0, gob.transform.position.z + Storage.v3.z);//(gob.transform.position.x + x, 0, gob.transform.position.z + z);//
                    gob.transform.SetParent(Storage.movePath.transform);
                    Storage.CreateInformation.Add(gob);
                    //Storage.CreateInformation.Add(gob.GetComponentInChildren<MeshRenderer>());
                    Storage.v3.x += xx;
                    Storage.v3.z += zx;
                }
                startPos.transform.position = pos[i].position;
            }
        }
        //Storage.obj = GameObject.Instantiate(Resources.Load("Move")) as GameObject;
        //if (Storage.GPSPath != null) { startPos.transform.SetParent(Storage.GPSPath.transform); }
        Storage.v3 = Vector3.zero;
    }
}
